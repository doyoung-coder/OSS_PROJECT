package com.yeongnam.deeplocal.controller;

import com.yeongnam.deeplocal.model.Review;
import com.yeongnam.deeplocal.model.User; // User 모델 임포트 확인 필요
import com.yeongnam.deeplocal.repository.ReviewRepository;
import com.yeongnam.deeplocal.repository.UserRepository;
import com.yeongnam.deeplocal.controller.ReviewDto; // DTO 임포트 확인 필요
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UserRepository userRepository;

    // 1. 리뷰 작성 (항상 PENDING 상태로 저장)
    @PostMapping
    public ResponseEntity<?> createReview(@RequestBody ReviewDto dto) {
        Review review = new Review();
        review.setPlaceName(dto.getSpotName());
        review.setContent(dto.getContent());
        review.setCountry(dto.getCountry());
        review.setRegion(dto.getRegion());
        review.setLocation(dto.getLocation());
        review.setAuthorEmail(dto.getUserEmail());
        review.setStatus("PENDING");

        reviewRepository.save(review);
        return ResponseEntity.ok("리뷰가 성공적으로 등록되었습니다.");
    }

    // 2. 메인 페이지용: 관리자가 '승인(APPROVED)'한 리뷰만 보임
    @GetMapping("/list")
    public List<Review> getApprovedReviews() {
        return reviewRepository.findByStatus("APPROVED");
    }

    // 3. 관리자 페이지용: '대기 중(PENDING)'인 리뷰만 보임
    @GetMapping("/pending")
    public List<Review> getPendingReviews() {
        return reviewRepository.findByStatus("PENDING");
    }

    // 4. 리뷰 상태 업데이트 (수락/거절 처리 및 포인트 지급)
    @PostMapping("/{id}/status")
    public ResponseEntity<?> updateReviewStatus(@PathVariable Long id, @RequestBody Map<String, String> statusMap) {
        // 리뷰 조회
        Review review = reviewRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 리뷰를 찾을 수 없습니다."));

        String status = statusMap.get("status");
        review.setStatus(status);
        reviewRepository.save(review);

        // 💡 핵심 로직: 수락(APPROVED) 시 작성자에게 100 포인트 지급
        if ("APPROVED".equals(status)) {
            userRepository.findByEmail(review.getAuthorEmail()).ifPresent(user -> {
                int currentPoints = user.getPoints() != null ? user.getPoints() : 0;
                user.setPoints(currentPoints + 100);
                userRepository.save(user);
            });
        }

        return ResponseEntity.ok("상태가 성공적으로 업데이트되었습니다.");
    }
}