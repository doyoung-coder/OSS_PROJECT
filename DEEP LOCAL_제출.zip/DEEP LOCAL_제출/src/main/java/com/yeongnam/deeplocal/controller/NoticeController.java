package com.yeongnam.deeplocal.controller;

import com.yeongnam.deeplocal.model.Notice;
import com.yeongnam.deeplocal.repository.NoticeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/notices")
public class NoticeController {

    @Autowired
    private NoticeRepository noticeRepository;

    // 공지 작성 (POST)
    @PostMapping
    public Notice create(@RequestBody Notice notice) {
        return noticeRepository.save(notice);
    }

    // 공지 조회 (GET)
    @GetMapping
    public List<Notice> getAllNotices() {
        return noticeRepository.findAll();
    }
}