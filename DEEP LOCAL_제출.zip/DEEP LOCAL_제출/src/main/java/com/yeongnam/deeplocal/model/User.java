package com.yeongnam.deeplocal.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "users") // 'user' 대신 'users'로 테이블 이름을 변경합니다.
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String email;
    private String name;
    private String password;

    // 💡 AuthController의 getNickname() 에러를 해결하기 위해 필드 추가
    private String nickname;

    // 💡 AuthController의 getPoints() 에러를 해결하고 기본값을 0으로 세팅하기 위해 필드 추가
    private Integer points = 0;
}