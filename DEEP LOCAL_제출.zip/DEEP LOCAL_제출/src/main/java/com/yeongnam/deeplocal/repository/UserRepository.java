package com.yeongnam.deeplocal.repository;

import com.yeongnam.deeplocal.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional; // 💡 Optional 타입을 사용하기 위해 필수로 추가된 임포트문입니다.

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // 이 메서드가 있어야 이메일 중복 검사가 가능합니다.
    boolean existsByEmail(String email);

    // 💡 추가된 메서드: 로그인 시 이메일을 기반으로 DB에서 유저 정보를 안전하게 찾아옵니다.
    Optional<User> findByEmail(String email);
}