package com.yeongnam.deeplocal.controller;

import com.yeongnam.deeplocal.model.Comment;
import com.yeongnam.deeplocal.repository.CommentRepository;
import org.springframework.web.bind.annotation.*; // @RestController, @RequestMapping, @PostMapping, @GetMapping, @PathVariable, @RequestBody 포함
import org.springframework.beans.factory.annotation.Autowired; // @Autowired
import java.util.List;

@RestController
@RequestMapping("/api/comments")
public class CommentController {
    @Autowired private CommentRepository commentRepository;

    @PostMapping("/{reviewId}")
    public void addComment(@PathVariable Long reviewId, @RequestBody Comment comment) {
        comment.setReviewId(reviewId);
        commentRepository.save(comment);
    }

    @GetMapping("/{reviewId}")
    public List<Comment> getComments(@PathVariable Long reviewId) {
        return commentRepository.findByReviewId(reviewId);
    }
}
