package com.yeongnam.deeplocal.repository;

import com.yeongnam.deeplocal.model.ExchangeRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ExchangeRequestRepository extends JpaRepository<ExchangeRequest, Long> {

    // 상태가 'PENDING'인 환전 신청만 조회 (기존에 있던 코드)
    List<ExchangeRequest> findByStatus(String status);

    // 💡 사용자 이메일로 환전 내역을 최신순으로 조회 (새로 추가된 코드)
    List<ExchangeRequest> findByUserEmailOrderByIdDesc(String userEmail);
}