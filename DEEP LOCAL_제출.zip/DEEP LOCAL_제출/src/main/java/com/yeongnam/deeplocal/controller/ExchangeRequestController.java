package com.yeongnam.deeplocal.controller;

import com.yeongnam.deeplocal.model.ExchangeRequest;
import com.yeongnam.deeplocal.repository.ExchangeRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class ExchangeRequestController {

    @Autowired
    private ExchangeRequestRepository exchangeRequestRepository;

    // 1. 환전 신청 저장 (기존 코드)
    @PostMapping("/exchange/request")
    public void requestExchange(@RequestBody ExchangeRequest request) {
        request.setStatus("PENDING"); // 신청 시 기본값
        exchangeRequestRepository.save(request);
    }

    // 2. 대기 중인 환전 목록 조회 (관리자 대시보드용)
    @GetMapping("/admin/exchange/requests")
    public List<ExchangeRequest> getPendingRequests() {
        return exchangeRequestRepository.findByStatus("PENDING");
    }

    // 💡 3. 특정 사용자의 환전 신청 내역 조회 (새로 추가된 코드)
    @GetMapping("/exchange/my")
    public List<ExchangeRequest> getMyExchangeRequests(@RequestParam String email) {
        return exchangeRequestRepository.findByUserEmailOrderByIdDesc(email);
    }
}