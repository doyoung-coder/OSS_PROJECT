package com.yeongnam.deeplocal.service;

import com.yeongnam.deeplocal.model.User;
import com.yeongnam.deeplocal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // 이메일 중복 검사 기능
    public boolean isEmailDuplicate(String email) {
        return userRepository.existsByEmail(email);
    }

    // 💡 로그인 검증 비즈니스 로직 추가
    public Optional<User> authenticate(String email, String password) {
        return userRepository.findByEmail(email)
                .filter(user -> user.getPassword().equals(password));
    }
}