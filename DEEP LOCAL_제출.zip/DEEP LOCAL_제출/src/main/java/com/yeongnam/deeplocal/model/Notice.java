package com.yeongnam.deeplocal.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Notice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String content;
}