package com.yeongnam.deeplocal.model;

import jakarta.persistence.*; // @Entity, @Id, @GeneratedValue 관련
import lombok.Data;           // @Data 관련
import java.time.LocalDateTime;

@Entity
@Data
public class ExchangeRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userEmail;
    private int amount;
    private String status = "PENDING"; // PENDING, APPROVED, REJECTED
    private LocalDateTime createdAt = LocalDateTime.now();
    // ExchangeRequest.java 내부 (기존 코드에 필드만 추가)
    private String rejectReason; // 💡 거절 사유를 저장할 필드 추가
}
