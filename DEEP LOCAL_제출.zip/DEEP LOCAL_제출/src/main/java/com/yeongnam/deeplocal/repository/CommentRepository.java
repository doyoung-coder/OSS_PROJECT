package com.yeongnam.deeplocal.repository;

import com.yeongnam.deeplocal.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    // 특정 리뷰 ID에 달린 댓글만 가져오는 기능
    List<Comment> findByReviewId(Long reviewId);
}