package com.yeongnam.deeplocal.controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewDto {
    private String spotName;
    private String content;
    private String country;
    private String region;
    private String location;
    private String userEmail;
}