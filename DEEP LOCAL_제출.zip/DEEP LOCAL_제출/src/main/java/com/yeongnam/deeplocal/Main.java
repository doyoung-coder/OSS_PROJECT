package com.yeongnam.deeplocal; // 패키지 주소 일치 완료!

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main {

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    // 1. 유저가 있으면 ID 반환, 없으면 생성 후 ID 반환
    public static long getOrCreateUser(Connection conn, String email, String name) throws SQLException {
        String selectSql = "SELECT user_id FROM users WHERE email = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(selectSql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getLong("user_id");
        }

        String insertSql = "INSERT INTO users (email, name, points) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, email);
            pstmt.setString(2, name);
            pstmt.setInt(3, 0);
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) return rs.getLong(1);
        }
        return -1;
    }

    // 2. 리뷰 등록 함수
    public static void insertReview(Connection conn, long userId, String country, String region, String placeName, String text, String tags) {
        String sql = "INSERT INTO reviews (user_id, country, region, place_name, content, tags) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, userId);
            pstmt.setString(2, country);
            pstmt.setString(3, region);
            pstmt.setString(4, placeName);
            pstmt.setString(5, text);
            pstmt.setString(6, tags);
            pstmt.executeUpdate();
            System.out.println("➡️ 리뷰 저장 성공!");
        } catch (SQLException e) {
            System.out.println("❌ 리뷰 저장 실패: " + e.getMessage());
        }
    }

    // 3. 전체 리뷰 출력 함수
    public static void selectAllReviews(Connection conn) throws SQLException {
        String sql = "SELECT * FROM reviews";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("\n--- 현재 데이터베이스에 저장된 리뷰 목록 ---");
            while (rs.next()) {
                System.out.println("장소: " + rs.getString("place_name") + " | 내용: " + rs.getString("content"));
            }
        }
    }
}