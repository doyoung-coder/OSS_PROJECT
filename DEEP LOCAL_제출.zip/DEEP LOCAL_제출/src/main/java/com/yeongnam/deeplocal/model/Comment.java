package com.yeongnam.deeplocal.model;

import jakarta.persistence.*; // 중요
import lombok.Data;
import java.time.LocalDateTime; // 중요

@Entity
@Data
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long reviewId;
    private String writerEmail;
    private String content;
    private LocalDateTime createdAt = LocalDateTime.now();
}