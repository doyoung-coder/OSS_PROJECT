package com.yeongnam.deeplocal.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 프론트엔드의 spotName과 매칭됨
    private String placeName;
    private String content;

    // 💡 구글 맵 기능 추가로 인해 새롭게 추가된 필드들
    private String country;
    private String region;
    private String location;
    private String authorEmail;

    // 모든 새 리뷰는 무조건 '대기(PENDING)' 상태로 시작합니다.
    private String status = "PENDING";
}