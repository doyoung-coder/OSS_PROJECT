package com.yeongnam.deeplocal.controller;

import com.yeongnam.deeplocal.model.ExchangeRequest;
import com.yeongnam.deeplocal.model.User;
import com.yeongnam.deeplocal.repository.ExchangeRequestRepository;
import com.yeongnam.deeplocal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {

    @Autowired
    private ExchangeRequestRepository requestRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/exchange/approve/{requestId}")
    public void approveExchange(@PathVariable Long requestId) {
        // 1. 신청 내역 조회
        ExchangeRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("요청을 찾을 수 없습니다."));

        // 2. 상태 변경
        request.setStatus("APPROVED");
        requestRepository.save(request);

        // 3. 실제 사용자 포인트 차감
        userRepository.findByEmail(request.getUserEmail()).ifPresent(user -> {
            int currentPoints = user.getPoints() != null ? user.getPoints() : 0;
            user.setPoints(currentPoints - request.getAmount());
            userRepository.save(user);
        });
    }
    @PostMapping("/exchange/reject/{requestId}")
    public void rejectExchange(@PathVariable Long requestId, @RequestBody Map<String, String> body) {
        ExchangeRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("요청을 찾을 수 없습니다."));

        request.setStatus("REJECTED");
        request.setRejectReason(body.get("reason")); // 💡 프론트엔드에서 보낸 사유 저장
        requestRepository.save(request);
    }
}