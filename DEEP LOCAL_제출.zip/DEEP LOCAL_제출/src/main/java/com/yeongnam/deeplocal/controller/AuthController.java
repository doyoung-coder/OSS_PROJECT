package com.yeongnam.deeplocal.controller;

import com.yeongnam.deeplocal.model.User;
import com.yeongnam.deeplocal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api") // 전체 API의 공통 도메인 시작점
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // ==========================================
    // 회원가입 및 로그인 비즈니스 로직 (Auth 전담)
    // ==========================================

    @PostMapping("/auth/signup")
    public User signUp(@RequestBody User user) {
        return userRepository.save(user);
    }

    @PostMapping("/auth/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> loginData) {
        // 💡 1. Null 에러 방지 및 앞뒤 공백(Space) 완벽 제거
        String email = loginData.get("email") != null ? loginData.get("email").trim() : "";
        String password = loginData.get("password") != null ? loginData.get("password").trim() : "";

        System.out.println("로그인 시도 이메일: [" + email + "], 비밀번호: [" + password + "]");

        // 관리자 계정 체크
        if ("admin1234@admin.com".equals(email) && "admin1234".equals(password)) {
            return ResponseEntity.ok(Map.of("email", email, "role", "ADMIN", "name", "관리자"));
        }

        // 이메일 존재 확인
        Optional<User> userOptional = userRepository.findByEmail(email);
        if (userOptional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "회원가입 되지 않은 아이디입니다. 회원가입을 먼저 진행해 주세요."));
        }

        User user = userOptional.get();

        // 비밀번호 일치 확인 (DB에 있는 비밀번호도 공백을 제거하고 비교)
        if (!user.getPassword().trim().equals(password)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("message", "비밀번호가 일치하지 않습니다. 다시 확인해 주세요."));
        }

        String finalName = "게스트";
        if (user.getNickname() != null && !user.getNickname().trim().isEmpty()) {
            finalName = user.getNickname();
        } else if (user.getName() != null && !user.getName().trim().isEmpty()) {
            finalName = user.getName();
        }

        // 모든 검증 통과 시 로그인 성공 및 유저 정보 반환
        return ResponseEntity.ok(Map.of(
                "email", user.getEmail(),
                "role", "USER",
                "nickname", finalName,
                "name", finalName,
                "points", user.getPoints() != null ? user.getPoints() : 0
        ));
    }
}