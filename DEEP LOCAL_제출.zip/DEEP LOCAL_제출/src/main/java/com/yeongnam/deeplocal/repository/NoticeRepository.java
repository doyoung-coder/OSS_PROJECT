package com.yeongnam.deeplocal.repository;

import com.yeongnam.deeplocal.model.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository // 이 어노테이션이 있어야 서버가 이 Bean을 인식합니다.
public interface NoticeRepository extends JpaRepository<Notice, Long> {
}