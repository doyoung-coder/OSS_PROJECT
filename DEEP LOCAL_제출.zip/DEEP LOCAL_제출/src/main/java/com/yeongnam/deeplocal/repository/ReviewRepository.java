package com.yeongnam.deeplocal.repository;

import com.yeongnam.deeplocal.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    // 💡 핵심 쿼리 메서드: 특정 상태값(예: PENDING, APPROVED)을 가진 리뷰 목록만 필터링하여 가져옵니다.
    List<Review> findByStatus(String status);
}