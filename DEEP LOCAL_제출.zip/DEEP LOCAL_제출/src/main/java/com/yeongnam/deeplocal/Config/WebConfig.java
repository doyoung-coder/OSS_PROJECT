package com.yeongnam.deeplocal.Config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // 모든 API 주소에 대하여
                .allowedOriginPatterns("*") // 모든 외부 접속(React 등)을 허용
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // 허용할 요청 방식
                .allowedHeaders("*")
                .allowCredentials(true); // 인증 정보(토큰 등) 포함 허용
    }
}